import dev.langchain4j.agent.tool.Tool;
import dev.langchain4j.memory.chat.MessageWindowChatMemory;
import dev.langchain4j.model.openai.OpenAiChatModel;
import dev.langchain4j.service.AiServices;
import dev.langchain4j.service.MemoryId;
import dev.langchain4j.service.UserMessage;
import io.javalin.Javalin;
import io.javalin.http.staticfiles.Location;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.io.InputStream;
import java.time.Duration;
import java.util.Date;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.ParagraphAlignment;
import org.mindrot.jbcrypt.BCrypt;

public class PaperAssistant {

    interface Assistant {
        String chat(@MemoryId int memoryId, @UserMessage String userMessage);
    }

    static class CitationTool {

        @Tool("当用户要求检查、校验【参考文献】或【引文】格式时，必须调用此工具。传入参数为具体的引文内容。")
        public String verifyCitationFormat(String citation) {
            System.out.println("   [Agent 监控] 正在执行本地正则引文校验，目标内容: " + citation);

            boolean hasYearRegex = citation.matches(".*\\(\\d{4}\\)\\..*");

            if (hasYearRegex) {
                return "【校验通过】包含标准 APA 要求的年份括号格式。";
            } else {
                return "【校验失败】APA格式要求年份必须用括号括起来，例如 (2024)。请建议用户修改。";
            }
        }
    }

    static class CitationVerificationTool {

        @Tool("当需要核验参考文献的真实性，或者查找文献的出处时，必须调用此工具。传入参数为文献的标题。")
        public String verifyCitationReal(String paperTitle) {
            System.out.println("   [Agent 监控] 正在进行全网溯源与真实性核验: " + paperTitle);

            try {
                String encodedTitle = URLEncoder.encode(paperTitle, StandardCharsets.UTF_8);
                String scholarLink = "https://scholar.google.com/scholar?q=" + encodedTitle;

                String apiUrl = "https://api.crossref.org/works?query.bibliographic=" + encodedTitle + "&rows=1";

                HttpClient client = HttpClient.newBuilder()
                        .connectTimeout(Duration.ofSeconds(10))
                        .build();

                HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create(apiUrl))
                        .header("User-Agent", "AcademicAgent/1.0 (mailto:student@university.edu)")
                        .GET()
                        .build();

                HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

                ObjectMapper mapper = new ObjectMapper();
                JsonNode root = mapper.readTree(response.body());
                JsonNode items = root.path("message").path("items");

                if (items != null && items.isArray() && !items.isEmpty()) {
                    JsonNode firstItem = items.get(0);
                    String realTitle = firstItem.path("title").get(0).asText("未知标题");
                    String doiUrl = firstItem.path("URL").asText("无DOI链接");

                    return "【核验成功-文献真实存在】\n" +
                            "匹配标题: " + realTitle + "\n" +
                            "官方DOI: " + doiUrl + "\n" +
                            "搜索链接: " + scholarLink;
                } else {
                    return "【核验失败-疑似 AI 幻觉文献】未找到此文献。\n请强制附带此链接让用户核实: " + scholarLink;
                }

            } catch (java.net.http.HttpTimeoutException e) {
                System.err.println("   [Agent 监控] 跨国网络请求超时，已触发熔断保护...");
                return "【核验超时】数据库当前繁忙，请让用户手动查验: https://scholar.google.com/scholar?q=" + URLEncoder.encode(paperTitle, StandardCharsets.UTF_8);
            } catch (Exception e) {
                System.err.println("   [Agent 监控] API 请求发生不可逆异常: " + e.getMessage());
                return "【核验异常】无法连接数据库，请附带搜索链接让用户手动查验。";
            }
        }
    }

    static class FileStorageEngine {



        private static final String BASE_DIR = "uploads";

        public static String savePhysicalFile(InputStream is, String originalFileName) throws Exception {
            String dateDir = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
            Path dirPath = Paths.get(BASE_DIR, dateDir);

            Files.createDirectories(dirPath);

            String uuidPrefix = UUID.randomUUID().toString().substring(0, 8);
            String safeFileName = uuidPrefix + "_" + originalFileName;
            Path targetPath = dirPath.resolve(safeFileName);

            Files.copy(is, targetPath, StandardCopyOption.REPLACE_EXISTING);

            System.out.println("   [存储引擎] PDF 已完成物理持久化，位置: " + targetPath.toAbsolutePath());

            return targetPath.toString();
        }
    }

    static class AsyncTaskDispatcher {

        public static final ExecutorService THREAD_POOL = Executors.newFixedThreadPool(5);

        public static final Map<String, TaskState> TASK_MAP = new ConcurrentHashMap<>();

        public static class TaskState {
            private String status;
            private String report;

            public TaskState() {
            }

            public String getStatus() {
                return status;
            }

            public void setStatus(String status) {
                this.status = status;
            }

            public String getReport() {
                return report;
            }

            public void setReport(String report) {
                this.report = report;
            }
        }
    }

    static class DatabaseService {

        private static final String DB_URL = "jdbc:sqlite:academic_history.db";

        public static void initDatabase() {
            try (Connection conn = DriverManager.getConnection(DB_URL);
                 Statement stmt = conn.createStatement()) {

                String createUsersSql = "CREATE TABLE IF NOT EXISTS users (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "username TEXT UNIQUE NOT NULL, " +
                        "password_hash TEXT NOT NULL)";
                stmt.execute(createUsersSql);

                String createHistorySql = "CREATE TABLE IF NOT EXISTS paper_history (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "user_id INTEGER, " +
                        "file_name TEXT, " +
                        "file_path TEXT, " +
                        "ai_report TEXT, " +
                        "upload_time DATETIME DEFAULT CURRENT_TIMESTAMP)";
                stmt.execute(createHistorySql);

                System.out.println("   [数据层] SQLite 持久化表结构校验通过，准备就绪！");

            } catch (Exception e) {
                System.err.println("   [数据层] 数据库初始化发生致命异常: " + e.getMessage());
            }
        }

        public static void saveReport(int userId, String fileName, String filePath, String report) {
            String sql = "INSERT INTO paper_history(user_id, file_name, file_path, ai_report) VALUES(?, ?, ?, ?)";

            try (Connection conn = DriverManager.getConnection(DB_URL);
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {

                pstmt.setInt(1, userId);
                pstmt.setString(2, fileName);
                pstmt.setString(3, filePath);
                pstmt.setString(4, report);

                pstmt.executeUpdate();

            } catch (Exception e) {
                System.err.println("   [数据层] 数据插入失败: " + e.getMessage());
            }
        }

        public static String getAllHistoryJson(int userId) {
            String sql = "SELECT id, file_name, file_path, upload_time, ai_report FROM paper_history WHERE user_id = ? ORDER BY id DESC";
            List<Map<String, String>> historyList = new ArrayList<>();

            try (Connection conn = DriverManager.getConnection(DB_URL);
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {

                pstmt.setInt(1, userId);

                try (ResultSet rs = pstmt.executeQuery()) {
                    while (rs.next()) {
                        Map<String, String> record = new HashMap<>();
                        record.put("id", String.valueOf(rs.getInt("id")));
                        record.put("fileName", rs.getString("file_name"));
                        record.put("filePath", rs.getString("file_path"));
                        record.put("uploadTime", rs.getString("upload_time"));
                        record.put("report", rs.getString("ai_report"));

                        historyList.add(record);
                    }
                }
            } catch (Exception e) {
                System.err.println("   [数据层] 数据查询失败: " + e.getMessage());
            }

            return new Gson().toJson(historyList);
        }
    }

    static class SecurityService {

        private static final String SECRET_KEY = "YourSuperSecretKeyForAcademicAgent";
        private static final Algorithm ALGORITHM = Algorithm.HMAC256(SECRET_KEY);

        public static boolean register(String username, String rawPassword) {
            String sql = "INSERT INTO users(username, password_hash) VALUES(?, ?)";

            try (Connection conn = DriverManager.getConnection(DatabaseService.DB_URL);
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {

                pstmt.setString(1, username);

                String hashedPassword = BCrypt.hashpw(rawPassword, BCrypt.gensalt());
                pstmt.setString(2, hashedPassword);

                pstmt.executeUpdate();
                return true;

            } catch (Exception e) {
                return false;
            }
        }

        public static String login(String username, String rawPassword) {
            String sql = "SELECT id, password_hash FROM users WHERE username = ?";

            try (Connection conn = DriverManager.getConnection(DatabaseService.DB_URL);
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {

                pstmt.setString(1, username);
                ResultSet rs = pstmt.executeQuery();

                if (rs.next()) {
                    String savedHash = rs.getString("password_hash");
                    if (BCrypt.checkpw(rawPassword, savedHash)) {

                        int userId = rs.getInt("id");

                        return JWT.create()
                                .withClaim("userId", userId)
                                .withClaim("username", username)
                                .withExpiresAt(new Date(System.currentTimeMillis() + 86400000L))
                                .sign(ALGORITHM);
                    }
                }
            } catch (Exception e) {
                System.err.println("   [安全层] 登录校验发生异常: " + e.getMessage());
            }
            return null;
        }

        public static Integer verifyToken(String token) {
            try {
                DecodedJWT jwt = JWT.require(ALGORITHM).build().verify(token);
                return jwt.getClaim("userId").asInt();
            } catch (Exception e) {
                return null;
            }
        }
    }

    static class WordExportTool {

        public static ByteArrayInputStream generateDocx(String fileName, String aiReport) {
            try (XWPFDocument document = new XWPFDocument();
                 ByteArrayOutputStream out = new ByteArrayOutputStream()) {

                XWPFParagraph titleParagraph = document.createParagraph();
                titleParagraph.setAlignment(ParagraphAlignment.CENTER);
                XWPFRun titleRun = titleParagraph.createRun();
                titleRun.setText("AI 学术审查与溯源报告");
                titleRun.setBold(true);
                titleRun.setFontSize(18);
                titleRun.setColor("003366");

                XWPFParagraph subTitlePara = document.createParagraph();
                XWPFRun subTitleRun = subTitlePara.createRun();
                subTitleRun.setText("分析文献: " + fileName);
                subTitleRun.setItalic(true);
                subTitleRun.setFontSize(12);

                String[] lines = aiReport.split("\n");
                for (String line : lines) {
                    XWPFParagraph para = document.createParagraph();
                    XWPFRun run = para.createRun();
                    run.setText(line);
                    run.setFontSize(11);

                    if (line.contains("【核验成功")) {
                        run.setColor("008000");
                    } else if (line.contains("【核验失败")) {
                        run.setColor("FF0000");
                        run.setBold(true);
                    }
                }

                document.write(out);
                return new ByteArrayInputStream(out.toByteArray());

            } catch (Exception e) {
                System.err.println("   [导出引擎] Word 构建失败: " + e.getMessage());
                return null;
            }
        }
    }

    public static class ChatRequest {
        private String message;
        public ChatRequest() {}
        public String getMessage() { return message; }
        public void setMessage(String message) { this.message = message; }
    }

    public static class AuthRequest {
        private String username;
        private String password;
        public AuthRequest() {}
        public String getUsername() { return username; }
        public void setUsername(String username) { this.username = username; }
        public String getPassword() { return password; }
        public void setPassword(String password) { this.password = password; }
    }

    public static void main(String[] args) {

        System.out.println("==========================================================");
        System.out.println("正在初始化企业级高并发学术中枢系统底座...");
        System.out.println("==========================================================");

        DatabaseService.initDatabase();

        OpenAiChatModel model = OpenAiChatModel.builder()
                .baseUrl("https://api.moonshot.cn/v1")
                .apiKey("sk-IxYavixxG5Uj609c5NVyD0XL6tp86z0tKJkDEqRZ8qijQTAA")
                .modelName("moonshot-v1-32k")
                .timeout(Duration.ofSeconds(300))
                .build();

        Assistant assistant = AiServices.builder(Assistant.class)
                .chatLanguageModel(model)
                .chatMemoryProvider(memoryId -> MessageWindowChatMemory.withMaxMessages(10))
                .tools(new CitationTool(), new CitationVerificationTool())
                .build();

        Javalin app = Javalin.create(config -> {
            config.staticFiles.add("/public", Location.CLASSPATH);
        }).start(8888);

        System.out.println("\n企业级异步流架构启动成功！请在浏览器中打开: http://localhost:8888\n");

        app.before("/api/*", ctx -> {

            String currentPath = ctx.path();
            if (currentPath.equals("/api/login") || currentPath.equals("/api/register")) {
                return;
            }

            String authHeader = ctx.header("Authorization");
            if (authHeader == null || !authHeader.startsWith("Bearer ")) {
                ctx.status(401).result("未授权访问：登录信息缺失！");
                return;
            }

            String token = authHeader.replace("Bearer ", "");
            Integer userId = SecurityService.verifyToken(token);

            if (userId == null) {
                ctx.status(401).result("未授权访问：Token 已失效或被篡改！");
            } else {
                ctx.attribute("userId", userId);
            }
        });

        app.post("/api/register", ctx -> {
            AuthRequest req = ctx.bodyAsClass(AuthRequest.class);

            boolean isRegistered = SecurityService.register(req.getUsername(), req.getPassword());
            if (isRegistered) {
                ctx.status(200).result("注册成功，请立即登录系统！");
            } else {
                ctx.status(400).result("注册失败：此用户名可能已被其他人员占用。");
            }
        });

        app.post("/api/login", ctx -> {
            AuthRequest req = ctx.bodyAsClass(AuthRequest.class);

            String token = SecurityService.login(req.getUsername(), req.getPassword());
            if (token != null) {
                Map<String, String> response = new HashMap<>();
                response.put("token", token);
                response.put("message", "登录认证成功");
                ctx.status(200).json(response);
            } else {
                ctx.status(401).result("认证失败：提供的账号或密码不匹配！");
            }
        });

        app.post("/api/chat", ctx -> {
            Integer userId = ctx.attribute("userId");
            ChatRequest req = ctx.bodyAsClass(ChatRequest.class);

            String aiResponse = assistant.chat(userId, req.getMessage());

            ctx.status(200).result(aiResponse);
        });

        app.post("/api/upload", ctx -> {
            io.javalin.http.UploadedFile uploadedFile = ctx.uploadedFile("file");

            if (uploadedFile != null) {
                Integer userId = ctx.attribute("userId");
                String originalFileName = uploadedFile.filename();

                try {
                    String physicalFilePath = FileStorageEngine.savePhysicalFile(
                            uploadedFile.content(),
                            originalFileName
                    );

                    String taskId = UUID.randomUUID().toString();
                    AsyncTaskDispatcher.TaskState taskState = new AsyncTaskDispatcher.TaskState();
                    taskState.setStatus("PENDING");
                    AsyncTaskDispatcher.TASK_MAP.put(taskId, taskState);

                    AsyncTaskDispatcher.THREAD_POOL.submit(() -> {
                        try {
                            taskState.setStatus("PROCESSING");

                            System.out.println("   [调度中心] 🔄 异步执行队列已接管任务号: " + taskId);


                            File targetFile = new File(physicalFilePath);
                            PDDocument document = PDDocument.load(targetFile);
                            int totalPages = document.getNumberOfPages();


                            System.out.println("   [PDFBox 切割引擎] 正在加载论文，原始总页数: " + totalPages);

                            PDFTextStripper stripper = new PDFTextStripper();


                            stripper.setStartPage(1);
                            stripper.setEndPage(1);
                            String firstPageText = stripper.getText(document);


                            System.out.println("   [PDFBox 切割引擎]  正在动态剥离第 1 页与最后 2 页核心语料...");

                            stripper.setStartPage(Math.max(2, totalPages - 1));
                            stripper.setEndPage(totalPages);
                            String lastPagesText = stripper.getText(document);

                            document.close();


                            String pdfText = "【头部内容摘要】\n" + firstPageText + "\n\n【尾部参考文献】\n" + lastPagesText;
                            String prompt = "我上传了一篇裁剪后的学术论文。请简要总结要点，并挑选最后【1条】参考文献使用工具溯源。\n\n内容：\n" + pdfText;

                            String aiResponse = assistant.chat(userId, prompt);

                            DatabaseService.saveReport(userId, originalFileName, physicalFilePath, aiResponse);

                            taskState.setReport(aiResponse);
                            taskState.setStatus("COMPLETED");
                            System.out.println("   [调度中心] 流水线任务彻底完结: " + taskId);

                        } catch (Exception e) {
                            taskState.setStatus("FAILED");
                            taskState.setReport("系统在处理您的文档时发生底层异常: " + e.getMessage());
                            e.printStackTrace();
                        }
                    });

                    Map<String, String> asyncResponse = new HashMap<>();
                    asyncResponse.put("taskId", taskId);
                    ctx.status(200).json(asyncResponse);

                } catch (Exception e) {
                    ctx.status(500).result("服务器内部 IO 存储失败：" + e.getMessage());
                }
            } else {
                ctx.status(400).result("无效的请求：未捕捉到 Multi-Part 文件流！");
            }
        });

        app.get("/api/task/{taskId}", ctx -> {

            String taskId = ctx.pathParam("taskId");

            AsyncTaskDispatcher.TaskState state = AsyncTaskDispatcher.TASK_MAP.get(taskId);

            if (state == null) {
                ctx.status(404).result("未找到对应的流水线任务注册信息。");
            } else {
                ctx.status(200).json(state);
            }
        });

        app.get("/api/history", ctx -> {
            Integer userId = ctx.attribute("userId");

            String jsonPayload = DatabaseService.getAllHistoryJson(userId);
            ctx.contentType("application/json").status(200).result(jsonPayload);
        });

        app.get("/api/download/pdf", ctx -> {
            String filePath = ctx.queryParam("filePath");
            String fileName = ctx.queryParam("fileName");

            if (filePath != null && Files.exists(Paths.get(filePath))) {

                String encodedFileName = URLEncoder.encode(fileName, StandardCharsets.UTF_8);
                ctx.header("Content-Disposition", "attachment; filename=" + encodedFileName);
                ctx.contentType("application/pdf");

                try {
                    InputStream fileStream = Files.newInputStream(Paths.get(filePath));
                    ctx.status(200).result(fileStream);
                } catch (Exception e) {
                    ctx.status(500).result("物理文件流读取失败。");
                }
            } else {
                ctx.status(404).result("警告：在服务器磁盘节点上未能检索到该文件实体！");
            }
        });

        app.get("/api/export", ctx -> {
            String fileName = ctx.queryParam("fileName");
            String report = ctx.queryParam("report");

            ByteArrayInputStream docxStream = WordExportTool.generateDocx(fileName, report);

            if (docxStream != null) {
                String encodedFileName = URLEncoder.encode(fileName + "_深度分析报告.docx", StandardCharsets.UTF_8);
                ctx.header("Content-Disposition", "attachment; filename=" + encodedFileName);
                ctx.contentType("application/vnd.openxmlformats-officedocument.wordprocessingml.document");
                ctx.status(200).result(docxStream);
            } else {
                ctx.status(500).result("后台 POI 引擎生成 Word 文档发生严重错误。");
            }
        });
    }
}